package br.com.QI.poligono;

import java.util.Scanner;

public class Calculo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite a quantidade de lados: ");
        switch (sc.nextInt()) {
            case 3 -> {
                System.out.println("digite as medidas, respectivamente a Base X Altura: ");
                System.out.println("A Área é: " + ((sc.nextDouble() * sc.nextDouble())/2));
            }
            case 4 -> {
                System.out.println("digite a medida de um dos lados do quadrado: ");
                System.out.println("A Área é: " + Math.pow(sc.nextInt(), 2));
            }
            default -> System.out.println("Número de Lados Invalido");
        }
    }
}
