package br.com.QI.cinema;

import java.util.Scanner;

public class Entrada {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         
        System.out.println("Digite a sua idade");
        double valorIngresso = (sc.nextInt() >= 60) ? 15 : 30;
        System.out.println("O valor do ingresso é " + valorIngresso);
        
    }
}
