/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.biblioteca;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author joaovjc
 */
public class Comprar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        List<Livro> livros = new LinkedList<>();
        List<Livro> carrinho = new ArrayList<>();
        livros.add(new Livro("Java Para Iniciantes", 1500.0));
        livros.add(new Livro("Java Intermediario", 300.0));
        livros.add(new Livro("Java avançado", 200.0));
        livros.add(new Livro("Java Servlet", 1000.0));
        livros.add(new Livro("Maven", 3000.0));
        livros.add(new Livro("Java Rest", 200.0));
        livros.add(new Livro("AJAX", 1250.0));
        
        
        double d = 0;
        int f, b, a = 0;
        do{
             System.out.println("Estes são os livros a venda: ");
             System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            livros.forEach(l ->{
                System.out.println(l);
            });
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.print("Digite o numero da posição do Livro que quer colocar em seu carrinho(para sair digite 0): ");
            f = sc.nextInt();
            if(f <= livros.size() && f > 0) {
                System.out.print("Tem certeza que quer colocar este livro em seu carrinho? " + livros.get(f-1).getNomeDoLivro()  + "(Digite 1 para sim e 0 para não)");
                do{
                    b = sc.nextInt();
                    if (b != 0 || b != 1) {
                        int h = f-1;
                        carrinho.add(livros.get(h));
                        livros.remove(h);
                        System.out.println("Livro adicionado ao carrinho");
                        a++;
                    }else System.out.println("numero inválido, digite novamente; (Digite 1 para sim e 0 para não) ");
                }while(!(b == 0 || b == 1));
            }else if(f != 0){
                System.out.println("Não existe este livro");
            }
        }while(f != 0);
        System.out.print("o Total sera de: R$" );
        if (carrinho.size() >= 5) {
            for (Livro livro : carrinho) {
                d += livro.getPreco() - (livro.getPreco()* 0.5);
            }
        }else{
            for (Livro livro : carrinho) {
                d += livro.getPreco();
            }
        }   
        System.out.print(d);
    }
        
        
}
