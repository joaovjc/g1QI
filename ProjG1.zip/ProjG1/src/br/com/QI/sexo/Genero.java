/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.sexo;

import java.util.Scanner;

/**
 *
 * @author joaovjc
 */
public class Genero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         
        System.out.print("Digite m ou f: ");
        switch (sc.nextLine().toLowerCase()) {
            case "feminino", "f" -> System.out.println("Feminino");
            case "masculino", "m" -> System.out.println("Masculino");
            default -> System.out.println("Terceiro Sexo!");
        }
        
    }
}
