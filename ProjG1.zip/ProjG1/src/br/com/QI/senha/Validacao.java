package br.com.QI.senha;

import java.util.Scanner;

public class Validacao {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite a sua senha: "); 
        System.out.println((1234 == sc.nextInt()) ? "Senha correta" : "senha incorreta");
    }
}
