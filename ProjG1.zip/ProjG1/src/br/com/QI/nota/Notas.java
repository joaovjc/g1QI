package br.com.QI.nota;

import java.util.Scanner;

public class Notas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite o nome: ");
        String nome = sc.nextLine();
        System.out.print("Digite o nome da dsciplina: ");
        String d = sc.nextLine();
        System.out.print("Digite as 3 notas: ");
        
        double nF = ((sc.nextDouble() + sc.nextDouble() + sc.nextDouble())/3);
        System.out.println("digite a frequencia em porcentagem: ");
        int p = sc.nextInt();
        System.out.println( ((nF >= 6) && ((p) >= 75)) ? "o Aluno " + nome + " cursando a disciplina " + d +" esta Aprovado, com nota " + nF+ "e um total de "+ p +"% de presença" :
                "o Aluno " + nome + " cursando a disciplina " + d +" esta Reprovado, com nota " + nF+ " e um total de "+ p +"% de presença");
    }   
}
